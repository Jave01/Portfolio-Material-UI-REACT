import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from '../Header/Nav'; 
import Carousels from '../Carousels/Carousels';
import Cards1 from '../Cards1/Cards1';
import Cards2 from '../Cards2/Cards2';
import Form from '../Form/Form';
import Footer from '../Footer/Footer';

const RoutesConfig = () => {
  return (
    <>
      {/* Navbar Always Visible */}
      <Header />
      <Carousels />
      {/* <Cards1 />
      <Cards2 /> */}

      {/* Routes */}
      <Routes>
        <Route path="/about" element={<Cards1 />} />
        <Route path="/services" element={<Cards2 />} />
        <Route path="/contact" element={<Form />} />
      </Routes>

      {/* Footer Always Visible */}
      {/* <Form /> */}
      <Footer />
    </>
  );
};

export default RoutesConfig;
