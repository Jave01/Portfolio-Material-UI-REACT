import * as React from 'react';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';

export default function TitlebarImageList() {
  return (
    <ImageList sx={{ width: '100%', height: 'auto' }} cols={1}>
      {itemData.map((item) => (
        <ImageListItem key={item.img} sx={{ position: 'relative', maxHeight: '500px', overflow: 'hidden' }}>
          {/* Background Image */}
          <img
            srcSet={`${item.img}?w=800&fit=crop&auto=format&dpr=2 2x`}
            src={`${item.img}?w=800&fit=crop&auto=format`}
            alt={item.title}
            loading="lazy"
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
          
          {/* Overlay Content */}
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
              backgroundColor: 'rgba(0, 0, 0, 0.6)', // Darkened overlay
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'column',
              textAlign: 'center',
              color: 'white',
              p: 3,
            }}
          >
            {/* Title Text */}
            <Typography
              variant="h3"
              sx={{
                fontWeight: 'bold',
                fontSize: { xs: '2rem', sm: '3rem', md: '4rem', lg: '5rem' },
                letterSpacing: '2px',
                textTransform: 'uppercase',
                textShadow: '2px 2px 10px rgba(0, 0, 0, 0.8)',
                mb: 3,
              }}
            >
              {item.title}
            </Typography>

            {/* Action Button */}
            <Button
              variant="contained"
              disableElevation
              sx={{
                bgcolor: '#1976d2',
                color: 'white',
                fontSize: '1.1rem',
                fontWeight: 'bold',
                px: 4,
                py: 1.5,
                borderRadius: '8px',
                textTransform: 'none',
                '&:hover': { bgcolor: '#135ba1' }, // Darker shade on hover
              }}
            >
              View More
            </Button>
          </Box>
        </ImageListItem>
      ))}
    </ImageList>
  );
}

const itemData = [
  {
    img: 'https://images.pexels.com/photos/1181352/pexels-photo-1181352.jpeg?auto=compress&cs=tinysrgb&w=600',
    title: 'Hi, I am Javeria Mumtaz, a MERN Stack Developer',
  },
];
