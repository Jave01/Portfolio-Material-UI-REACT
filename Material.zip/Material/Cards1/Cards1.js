import * as React from 'react';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Slider from '@mui/material/Slider';
import Button from '@mui/material/Button';

export default function ImageWithSliders() {
  return (
    <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center', py: 4 }}>
      <Stack
        spacing={4}
        direction="row"
        alignItems="center"
        sx={{ maxWidth: '90%', width: '100%', justifyContent: 'center' }}
      >
        {/* Left Side - Image */}
        <Box
          component="img"
          src="https://images.pexels.com/photos/1181352/pexels-photo-1181352.jpeg?auto=compress&cs=tinysrgb&w=600"
          alt="Javeria Mumtaz"
          sx={{
            width: '50%', 
            height: '100%', 
            maxHeight: 600, 
            borderRadius: 2,
            objectFit: 'cover',
          }}
        />

        {/* Right Side - Content */}
        <Box sx={{ width: '50%', textAlign: 'left', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          {/* Title */}
          <Box sx={{ fontSize: '2rem', fontWeight: 'bold', mb: 2 }}>
            Hi, I'm Javeria Mumtaz, a MERN Stack Developer
          </Box>

          {/* Description */}
          <Box sx={{ fontSize: '1.2rem', color: 'gray', mb: 3 }}>
            I specialize in building dynamic, scalable, and high-performance web applications using the MERN Stack.  
            With expertise in **MongoDB, Express.js, React.js, and Node.js**, I create full-stack solutions that  
            enhance user experience and business growth. From interactive frontends to robust backends, I turn ideas into reality.
          </Box>

          {/* Skills & Expertise - Sliders Section */}
          <Box>
            <h3>Website Development</h3>
            <Slider disabled={false} valueLabelDisplay="on" defaultValue={90} sx={{ width: '90%', color: 'primary.main' }} />
          </Box>

          <Box>
            <h3>UI/UX Design</h3>
            <Slider disabled={false} valueLabelDisplay="on" defaultValue={80} sx={{ width: '90%', color: 'secondary.main' }} />
          </Box>

          <Box>
            <h3>SEO Optimization</h3>
            <Slider disabled={false} valueLabelDisplay="on" defaultValue={85} sx={{ width: '90%', color: 'success.main' }} />
          </Box>

          {/* CTA Button */}
          <Button variant="contained" disableElevation sx={{ bgcolor: '#1976d2', color: 'white', fontSize: '1rem', mt: 2 }}>
            View My Work
          </Button>
        </Box>
      </Stack>
    </Box>
  );
}
