export const Navlinks = [
    { name: 'Home', link: '/' },
    { name: 'About', link: '/about' },
    { name: 'Services', link: '/services' },
    { name: 'Portfolio', link: '/portfolio' },
    { name: 'Contact', link: '/contact' },
  ];
  