import React from 'react';
import { Link } from 'react-router-dom';
import { Box, Typography, IconButton, Container, Button } from '@mui/material';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import InstagramIcon from '@mui/icons-material/Instagram';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import { Navlinks } from '../NavLinks/Navlinks'; 

function Footer() {
  return (
    <Box sx={{ bgcolor: '#1976d2', color: 'white', py: 3 }}>
      <Container maxWidth="xl">
        {/* Navigation Links */}
        <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: 3, mb: 2 }}>
          {Navlinks.map((page) => (
            <Button key={page.name} component={Link} to={page.link} sx={{ color: 'white', fontSize: '16px' }}>
              {page.name}
            </Button>
          ))}
        </Box>

        {/* Social Media Links */}
        <Box sx={{ textAlign: 'center', mb: 2 }}>
          <IconButton href="https://www.facebook.com/share/15nvpLpKCB/" target="_blank" sx={{ color: 'white', mx: 1 }}>
            <FacebookIcon />
          </IconButton>
          <IconButton href="#" sx={{ color: 'white', mx: 1 }}>
            <TwitterIcon />
          </IconButton>
          <IconButton href="https://www.instagram.com/javeriamumtazabbasi?igsh=MTVvcHVsbGtiazkyZQ==" target="_blank" sx={{ color: 'white', mx: 1 }}>
            <InstagramIcon />
          </IconButton>
          <IconButton href="https://www.linkedin.com/in/javeria-mumtaz01?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" target="_blank" sx={{ color: 'white', mx: 1 }}>
            <LinkedInIcon />
          </IconButton>
        </Box>

        {/* Copyright Text */}
        <Typography variant="body2" align="center">
          © {new Date().getFullYear()} Javeria Mumtaz. All rights reserved.
        </Typography>
      </Container>
    </Box>
  );
}

export default Footer;
