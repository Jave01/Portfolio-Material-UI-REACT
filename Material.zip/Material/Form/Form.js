import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';

export default function ContactForm() {
  return (
    <Box
      sx={{
        height: '100vh', // Full screen height
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        bgcolor: '#f4f4f4', // Light background color
      }}
    >
      <Box
        sx={{
          width: 500,
          maxWidth: '90%', // Responsive width
          display: 'flex',
          flexDirection: 'column',
          gap: 2,
          padding: 4,
          borderRadius: 2,
          boxShadow: 3,
          bgcolor: 'white',
          textAlign: 'center',
        }}
      >
        <h2>Contact Me</h2>
        <TextField fullWidth label="Your Name" id="name" />
        <TextField fullWidth label="Email" id="email" type="email" />
        <TextField fullWidth label="Your Message" id="message" multiline rows={4} />
        <Button variant="contained" color="primary">Submit</Button>
      </Box>
    </Box>
  );
}
