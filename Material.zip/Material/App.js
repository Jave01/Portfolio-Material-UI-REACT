import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import Routesconfig from './Router/Routesconfig'; // Fixed import

function App() {
  return (
    <Router>
      <Routesconfig />
    </Router>
  );
}

export default App;
